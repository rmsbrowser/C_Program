/* map.c 12-Jan-96 */

/****************************************************************
 * (C)opyright (C) 1993,1996  Martin Stover, Marburg, Germany   *
 ****************************************************************/

#include "net.h"

int func_slist(int argc, char *argv[], int mode)
{




}
